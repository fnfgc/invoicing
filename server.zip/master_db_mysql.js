const mysql = require('mysql2');
const pool = require('./mysql_config');
const bcrypt = require('bcryptjs');

// Wrapper to mimic SQLite API for backward compatibility
const db = {
    run: (sql, params, callback) => {
        // Handle optional params
        if (typeof params === 'function') {
            callback = params;
            params = [];
        }
        
        pool.query(sql, params, function(err, results) {
            if (callback) {
                // Mimic SQLite 'this' context for lastID and changes
                const context = {};
                if (results) {
                    context.lastID = results.insertId;
                    context.changes = results.affectedRows;
                }
                callback.call(context, err);
            }
        });
    },
    get: (sql, params, callback) => {
        if (typeof params === 'function') {
            callback = params;
            params = [];
        }
        pool.query(sql, params, (err, results) => {
            if (err) return callback(err);
            // Return first row or undefined
            callback(null, results && results.length > 0 ? results[0] : undefined);
        });
    },
    all: (sql, params, callback) => {
        if (typeof params === 'function') {
            callback = params;
            params = [];
        }
        pool.query(sql, params, (err, results) => {
            callback(err, results);
        });
    }
    // Note: 'serialize' and 'prepare' are not fully implemented as wrappers
    // because they are specific to SQLite's control flow.
    // We will handle initialization explicitly below.
};

const initDB = async () => {
    const promisePool = pool.promise();

    try {
        // Packages Table
        await promisePool.query(`CREATE TABLE IF NOT EXISTS packages (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            price DECIMAL(10, 2) NOT NULL,
            duration_days INT NOT NULL,
            features TEXT,
            ai_enabled TINYINT(1) DEFAULT 0,
            accounting_enabled TINYINT(1) DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )`);

        // Migration: Ensure new columns exist
        try {
            await promisePool.query("ALTER TABLE packages ADD COLUMN ai_enabled TINYINT(1) DEFAULT 0");
        } catch (e) {
            // Ignore "Duplicate column name" error (Code 1060)
            if (e.errno !== 1060) console.warn("Migration warning (ai_enabled):", e.message);
        }
        try {
            await promisePool.query("ALTER TABLE packages ADD COLUMN accounting_enabled TINYINT(1) DEFAULT 1");
        } catch (e) {
            if (e.errno !== 1060) console.warn("Migration warning (accounting_enabled):", e.message);
        }

        try {
            await promisePool.query("ALTER TABLE packages ADD COLUMN website_enabled TINYINT(1) DEFAULT 1");
        } catch (e) {
            if (e.errno !== 1060) console.warn("Migration warning (website_enabled):", e.message);
        }

        // Tenants Table
        await promisePool.query(`CREATE TABLE IF NOT EXISTS tenants (
            id INT AUTO_INCREMENT PRIMARY KEY,
            business_name VARCHAR(255) NOT NULL,
            email VARCHAR(255) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            plan VARCHAR(255) DEFAULT 'free',
            subscription_expiry DATETIME,
            is_active TINYINT(1) DEFAULT 1,
            custom_domain VARCHAR(255) UNIQUE,
            slug VARCHAR(255) UNIQUE,
            website_enabled TINYINT(1) DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )`);

        try {
            await promisePool.query("ALTER TABLE tenants ADD COLUMN website_enabled TINYINT(1) DEFAULT 1");
        } catch (e) {
            if (e.errno !== 1060) console.warn("Migration warning (website_enabled):", e.message);
        }

        try {
            await promisePool.query("ALTER TABLE tenants ADD COLUMN custom_domain VARCHAR(255) UNIQUE");
        } catch (e) {
            // Ignore "Duplicate column name" error (Code 1060)
            if (e.errno !== 1060) console.warn("Migration warning (custom_domain):", e.message);
        }

        try {
            await promisePool.query("ALTER TABLE tenants ADD COLUMN slug VARCHAR(255) UNIQUE");
            
            // Backfill logic for slug
            const [rows] = await promisePool.query("SELECT id, business_name FROM tenants WHERE slug IS NULL");
            for (const row of rows) {
                let slug = row.business_name.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
                if (!slug) slug = 'store';
                slug = slug + '-' + row.id;
                await promisePool.query("UPDATE tenants SET slug = ? WHERE id = ?", [slug, row.id]);
                console.log(`Backfilled slug for tenant ${row.id}: ${slug}`);
            }
        } catch (e) {
             if (e.errno !== 1060) console.warn("Migration warning (slug):", e.message);
        }

        // User Lookup Table
        await promisePool.query(`CREATE TABLE IF NOT EXISTS user_lookup (
            username VARCHAR(255) PRIMARY KEY,
            tenant_id INT NOT NULL,
            FOREIGN KEY(tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
        )`);

        await promisePool.query(`CREATE TABLE IF NOT EXISTS system_settings (
            \`key\` VARCHAR(255) PRIMARY KEY,
            \`value\` TEXT
        )`);

        // Insert Default Packages
        const [pkgRows] = await promisePool.query("SELECT count(*) as count FROM packages");
        if (pkgRows[0].count === 0) {
            const insertPkg = "INSERT INTO packages (name, price, duration_days, features, ai_enabled, accounting_enabled) VALUES (?, ?, ?, ?, ?, ?)";
            await promisePool.query(insertPkg, ["Trial", 0, 14, JSON.stringify(["Basic POS", "50 Products"]), 0, 1]);
            await promisePool.query(insertPkg, ["Monthly (Standard)", 19.99, 30, JSON.stringify(["Unlimited POS", "Unlimited Products", "Email Support"]), 0, 1]);
            await promisePool.query(insertPkg, ["Monthly (AI Pro)", 39.99, 30, JSON.stringify(["Unlimited POS", "Unlimited Products", "AI Insights", "Voice Commands", "Priority Support"]), 1, 1]);
            await promisePool.query(insertPkg, ["Yearly (Standard)", 199.99, 365, JSON.stringify(["All Features (No AI)", "Priority Support"]), 0, 1]);
            await promisePool.query(insertPkg, ["Yearly (AI Pro)", 399.99, 365, JSON.stringify(["All Features + AI", "Priority Support"]), 1, 1]);
            console.log("Default Packages Created (MySQL)");
        }

        // Super Admin
        const [adminRows] = await promisePool.query("SELECT * FROM tenants WHERE email = 'superadmin@fnf.com'");
        if (adminRows.length === 0) {
            const hash = bcrypt.hashSync('admin123', 10);
            await promisePool.query(`INSERT INTO tenants (business_name, email, password, plan, is_active) 
                    VALUES ('Super Admin', 'superadmin@fnf.com', ?, 'unlimited', 1)`, [hash]);
            console.log("Super Admin Created: superadmin@fnf.com / admin123");
        }

        const defaultPaymentInstructions = {
            bankName: "HBL",
            accountTitle: "FAIZAN RASHEED",
            accountNumber: "22207902038103",
            iban: "PK08HABB0022207902038103",
            branch: "FAISALABAD-AKBAR CHO",
            email: "info@fnfgc.com"
        };
        const [payRows] = await promisePool.query("SELECT `value` FROM system_settings WHERE `key` = ?", ["payment_instructions"]);
        if (!payRows || payRows.length === 0) {
            await promisePool.query(
                "INSERT INTO system_settings (`key`, `value`) VALUES (?, ?)",
                ["payment_instructions", JSON.stringify(defaultPaymentInstructions)]
            );
        }

    } catch (err) {
        console.error("Master DB Initialization Error:", err);
    }
};

// Run initialization
// initDB(); // Moved to export to allow control

module.exports = { ...db, initDB };
