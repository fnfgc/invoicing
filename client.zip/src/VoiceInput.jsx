import React, { useState, useRef } from 'react';
import { Mic, MicOff, Loader2, Lock } from 'lucide-react';
import api from './api';

const emitToast = (message, type = 'info', duration = 3500) => {
  if (typeof window === 'undefined') return;
  window.dispatchEvent(new CustomEvent('app-toast', { detail: { message, type, duration } }));
};

export default function VoiceInput({ onItemsRecognized, locked }) {
  const [isRecording, setIsRecording] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const mediaRecorderRef = useRef(null);
  const chunksRef = useRef([]);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorderRef.current = new MediaRecorder(stream);
      chunksRef.current = [];

      mediaRecorderRef.current.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };

      mediaRecorderRef.current.onstop = async () => {
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        setIsProcessing(true);

        const formData = new FormData();
        formData.append('audio', blob, 'voice_command.webm');

        try {
          const res = await api.post('/api/voice-command', formData, {
            headers: { 'Content-Type': 'multipart/form-data' }
          });

          if (res.data.matches && res.data.matches.length > 0) {
            onItemsRecognized(res.data.matches);
          } else {
            // Optional: notify user of no match
            console.log("No items matched");
          }
        } catch (err) {
          console.error('Voice command failed', err);
          // Optional: notify user of error
        } finally {
          setIsProcessing(false);
          // Stop all tracks to release microphone
          stream.getTracks().forEach(track => track.stop());
        }
      };

      mediaRecorderRef.current.start();
      setIsRecording(true);
    } catch (err) {
      console.error('Microphone access denied', err);
      emitToast('Microphone access denied. Please allow microphone access.', 'error');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const toggleRecording = () => {
    if (locked) {
        emitToast("Voice commands are available in the AI Pro plan. Please upgrade to use this feature.", 'info');
        return;
    }

    if (isRecording) {
      stopRecording();
    } else {
      startRecording();
    }
  };

  return (
    <button
      onClick={toggleRecording}
      disabled={isProcessing}
      className={`relative flex items-center justify-center w-10 h-10 rounded-full transition-all duration-300 ${
        locked 
          ? 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200' 
          : isRecording 
            ? 'bg-red-500 text-white animate-pulse shadow-lg shadow-red-500/50 ring-2 ring-red-300' 
            : isProcessing 
              ? 'bg-blue-50 text-blue-500 cursor-wait' 
              : 'bg-white border border-slate-200 text-slate-500 hover:bg-slate-50 hover:text-slate-900 shadow-sm'
      }`}
      title={locked ? "Upgrade to Pro for Voice Commands" : (isRecording ? "Stop Recording" : "Voice Command (Speak items)")}
    >
      {locked ? (
        <Lock size={16} />
      ) : isProcessing ? (
        <Loader2 size={18} className="animate-spin" />
      ) : isRecording ? (
        <MicOff size={18} />
      ) : (
        <Mic size={18} />
      )}
    </button>
  );
}
